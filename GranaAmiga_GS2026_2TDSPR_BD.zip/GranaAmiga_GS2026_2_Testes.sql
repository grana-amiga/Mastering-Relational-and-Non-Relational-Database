SET SERVEROUTPUT ON SIZE UNLIMITED

DELETE FROM transacao
 WHERE descricao = 'Gastei 30 no mercado'
   AND origem = 'WHATSAPP';

DELETE FROM leitura_energia
 WHERE id_dispositivo = 1
   AND dt_leitura = TIMESTAMP '2026-11-10 08:00:00';

COMMIT;

PROMPT ===== PRINT 1 - BLOCO 1: TERMOMETRO DO DINHEIRO =====

DECLARE
    c_limite_atencao  CONSTANT NUMBER := 70;
    c_limite_urgente  CONSTANT NUMBER := 90;

    v_ano             NUMBER(4)  := 2026;
    v_mes             NUMBER(2)  := 11;
    v_inicio          DATE;
    v_fim             DATE;

    v_total_familias  NUMBER;
    v_entradas        NUMBER(19,2);
    v_saidas          NUMBER(19,2);
    v_saldo           NUMBER(19,2);
    v_comprometido    NUMBER;
    v_nivel           VARCHAR2(30);

    v_qtd_verde       PLS_INTEGER := 0;
    v_qtd_amarelo     PLS_INTEGER := 0;
    v_qtd_vermelho    PLS_INTEGER := 0;
BEGIN
    v_inicio := TO_DATE(v_ano || LPAD(v_mes, 2, '0') || '01', 'YYYYMMDD');
    v_fim    := ADD_MONTHS(v_inicio, 1);

    SELECT COUNT(*)
      INTO v_total_familias
      FROM usuario
     WHERE papel = 'USER';

    DBMS_OUTPUT.PUT_LINE('TERMÔMETRO DO DINHEIRO - ' || TO_CHAR(v_inicio, 'MM/YYYY')
                         || ' - ' || v_total_familias || ' famílias');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 82, '-'));
    DBMS_OUTPUT.PUT_LINE(RPAD('Família', 26) || LPAD('Entradas', 13) || LPAD('Saídas', 13)
                         || LPAD('Saldo', 13) || LPAD('Comprom.', 10) || '  Nível');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 82, '-'));

    FOR fam IN (SELECT id_usuario, nome
                  FROM usuario
                 WHERE papel = 'USER'
                 ORDER BY id_usuario)
    LOOP
        SELECT NVL(SUM(CASE WHEN tipo = 'ENTRADA' THEN valor END), 0),
               NVL(SUM(CASE WHEN tipo = 'SAIDA'   THEN valor END), 0)
          INTO v_entradas, v_saidas
          FROM transacao
         WHERE id_usuario   = fam.id_usuario
           AND dt_transacao >= v_inicio
           AND dt_transacao <  v_fim;

        v_saldo := v_entradas - v_saidas;

        IF v_entradas <= 0 THEN
            IF v_saidas > 0 THEN
                v_comprometido := 100;
            ELSE
                v_comprometido := 0;
            END IF;
        ELSE
            v_comprometido := v_saidas * 100 / v_entradas;
        END IF;

        IF v_comprometido < c_limite_atencao THEN
            v_nivel := 'VERDE    - Tranquilo';
            v_qtd_verde := v_qtd_verde + 1;
        ELSIF v_comprometido < c_limite_urgente THEN
            v_nivel := 'AMARELO  - Atenção';
            v_qtd_amarelo := v_qtd_amarelo + 1;
        ELSE
            v_nivel := 'VERMELHO - Urgente';
            v_qtd_vermelho := v_qtd_vermelho + 1;
        END IF;

        DBMS_OUTPUT.PUT_LINE(RPAD(fam.nome, 26)
                             || LPAD(fn_formatar_brl(v_entradas), 13)
                             || LPAD(fn_formatar_brl(v_saidas), 13)
                             || LPAD(fn_formatar_brl(v_saldo), 13)
                             || LPAD(fn_formatar_pct(ROUND(v_comprometido, 2)), 10)
                             || '  ' || v_nivel);
    END LOOP;

    DBMS_OUTPUT.PUT_LINE(RPAD('-', 82, '-'));
    DBMS_OUTPUT.PUT_LINE('Resumo: ' || v_qtd_verde || ' tranquilas, '
                         || v_qtd_amarelo || ' em atenção e '
                         || v_qtd_vermelho || ' urgentes.');
END;
/

PROMPT ===== PRINT 2 - BLOCO 2: PLANO DE QUITACAO =====

DECLARE
    c_max_meses       CONSTANT PLS_INTEGER := 600;
    c_meses_exibidos  CONSTANT PLS_INTEGER := 12;

    v_mes             PLS_INTEGER;
    v_limite          PLS_INTEGER;
    v_saldo           NUMBER(19,2);
    v_juros           NUMBER(19,2);
    v_juros_iniciais  NUMBER(19,2);
    v_devido          NUMBER(19,2);
    v_pagamento       NUMBER(19,2);
    v_amortizacao     NUMBER(19,2);
    v_saldo_final     NUMBER(19,2);
    v_total_pago      NUMBER(19,2);
    v_total_juros     NUMBER(19,2);
BEGIN
    FOR d IN (SELECT id_divida, credor, saldo_devedor, taxa_juros_mes, valor_parcela
                FROM divida
               WHERE id_divida IN (2, 4)
                 AND status = 'ABERTA'
               ORDER BY id_divida)
    LOOP
        v_saldo         := d.saldo_devedor;
        v_mes           := 0;
        v_total_pago    := 0;
        v_total_juros   := 0;
        v_juros_iniciais := ROUND(v_saldo * d.taxa_juros_mes / 100, 2);

        DBMS_OUTPUT.PUT_LINE('PLANO DE QUITAÇÃO - ' || d.credor);
        DBMS_OUTPUT.PUT_LINE('Saldo ' || fn_formatar_brl(v_saldo)
                             || ' | juros ' || fn_formatar_pct(d.taxa_juros_mes) || ' ao mês'
                             || ' | parcela ' || fn_formatar_brl(d.valor_parcela));

        IF d.valor_parcela <= v_juros_iniciais THEN
            v_limite := c_meses_exibidos;
            DBMS_OUTPUT.PUT_LINE('AVISO: a parcela não supera os juros mensais ('
                                 || fn_formatar_brl(v_juros_iniciais) || ').');
        ELSE
            v_limite := c_max_meses;
        END IF;

        DBMS_OUTPUT.PUT_LINE(LPAD('Mês', 3) || LPAD('Saldo inicial', 16) || LPAD('Juros', 13)
                             || LPAD('Pagamento', 13) || LPAD('Amortiz.', 14) || LPAD('Saldo final', 15));

        WHILE v_saldo > 0 AND v_mes < v_limite LOOP
            v_mes         := v_mes + 1;
            v_juros       := ROUND(v_saldo * d.taxa_juros_mes / 100, 2);
            v_devido      := v_saldo + v_juros;
            v_pagamento   := LEAST(d.valor_parcela, v_devido);
            v_amortizacao := v_pagamento - v_juros;
            v_saldo_final := v_devido - v_pagamento;

            IF v_mes <= c_meses_exibidos THEN
                DBMS_OUTPUT.PUT_LINE(LPAD(v_mes, 3)
                                     || LPAD(fn_formatar_brl(v_saldo), 16)
                                     || LPAD(fn_formatar_brl(v_juros), 13)
                                     || LPAD(fn_formatar_brl(v_pagamento), 13)
                                     || LPAD(fn_formatar_brl(v_amortizacao), 14)
                                     || LPAD(fn_formatar_brl(v_saldo_final), 15));
            END IF;

            v_total_pago  := v_total_pago + v_pagamento;
            v_total_juros := v_total_juros + v_juros;
            v_saldo       := v_saldo_final;
        END LOOP;

        IF v_saldo = 0 THEN
            DBMS_OUTPUT.PUT_LINE('Quitação em ' || v_mes || ' meses. Total pago '
                                 || fn_formatar_brl(v_total_pago) || ', dos quais '
                                 || fn_formatar_brl(v_total_juros) || ' são juros.');
        ELSIF d.valor_parcela <= v_juros_iniciais THEN
            DBMS_OUTPUT.PUT_LINE('Sem quitação: após ' || v_mes || ' meses a dívida já está em '
                                 || fn_formatar_brl(v_saldo) || '. Aumente a parcela ou negocie.');
        ELSE
            DBMS_OUTPUT.PUT_LINE('A dívida não quita em até ' || c_max_meses
                                 || ' meses com a parcela informada.');
        END IF;
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 82, '-'));
    END LOOP;
END;
/

PROMPT ===== PRINT 3 - BLOCO 3: CURSOR - PRIORIDADE DAS DIVIDAS =====

DECLARE
    v_id_usuario      usuario.id_usuario%TYPE := 1;
    v_nome            usuario.nome%TYPE;
    v_renda           usuario.renda_mensal%TYPE;

    CURSOR c_dividas (p_id_usuario usuario.id_usuario%TYPE) IS
        SELECT id_divida, credor, tipo, saldo_devedor, taxa_juros_mes, valor_parcela
          FROM divida
         WHERE id_usuario = p_id_usuario
           AND status     = 'ABERTA'
         ORDER BY taxa_juros_mes DESC, saldo_devedor DESC;

    v_divida          c_dividas%ROWTYPE;
    v_posicao         PLS_INTEGER   := 0;
    v_juros_mes       NUMBER(19,2);
    v_total_parcelas  NUMBER(19,2)  := 0;
BEGIN
    SELECT nome, renda_mensal
      INTO v_nome, v_renda
      FROM usuario
     WHERE id_usuario = v_id_usuario;

    DBMS_OUTPUT.PUT_LINE('PRIORIDADE DAS DÍVIDAS - ' || v_nome);
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 82, '-'));

    OPEN c_dividas(v_id_usuario);
    LOOP
        FETCH c_dividas INTO v_divida;
        EXIT WHEN c_dividas%NOTFOUND;

        v_posicao        := v_posicao + 1;
        v_juros_mes      := ROUND(v_divida.saldo_devedor * v_divida.taxa_juros_mes / 100, 2);
        v_total_parcelas := v_total_parcelas + v_divida.valor_parcela;

        DBMS_OUTPUT.PUT_LINE(v_posicao || 'º ' || RPAD(v_divida.credor, 44)
                             || LPAD(fn_formatar_pct(v_divida.taxa_juros_mes), 8)
                             || ' | juros do mês ' || LPAD(fn_formatar_brl(v_juros_mes), 10)
                             || ' | parcela ' || fn_formatar_brl(v_divida.valor_parcela));
        IF v_posicao = 1 THEN
            DBMS_OUTPUT.PUT_LINE('   ^ maiores juros: pague esta primeiro');
        END IF;
    END LOOP;
    CLOSE c_dividas;

    IF v_posicao = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Nenhuma dívida aberta.');
    ELSIF v_renda IS NULL OR v_renda = 0 THEN
        DBMS_OUTPUT.PUT_LINE(v_posicao || ' dívida(s) aberta(s); parcelas somam '
                             || fn_formatar_brl(v_total_parcelas) || ' (renda não informada).');
    ELSE
        DBMS_OUTPUT.PUT_LINE(v_posicao || ' dívida(s) aberta(s); parcelas somam '
                             || fn_formatar_brl(v_total_parcelas) || ', ou '
                             || fn_formatar_pct(ROUND(v_total_parcelas * 100 / v_renda, 2))
                             || ' da renda de ' || fn_formatar_brl(v_renda) || '.');
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Usuário ' || v_id_usuario || ' não encontrado.');
END;
/

PROMPT ===== PRINT 4 - PROCEDIMENTO DE OPERACAO: PRC_REGISTRAR_TRANSACAO =====

DECLARE
    v_id_transacao  transacao.id_transacao%TYPE;
BEGIN
    prc_registrar_transacao(1, 4, 'SAIDA', 30, v_id_transacao,
                            p_descricao    => 'Gastei 30 no mercado',
                            p_origem       => 'WHATSAPP',
                            p_dt_transacao => TIMESTAMP '2026-11-10 18:30:00');

    BEGIN
        prc_registrar_transacao(1, 4, 'ENTRADA', 30, v_id_transacao);
    EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Erro esperado: ' || SQLERRM);
    END;

    BEGIN
        prc_registrar_transacao(1, 4, 'SAIDA', -5, v_id_transacao);
    EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Erro esperado: ' || SQLERRM);
    END;

    BEGIN
        prc_registrar_transacao(99, 4, 'SAIDA', 5, v_id_transacao);
    EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Erro esperado: ' || SQLERRM);
    END;
END;
/

PROMPT ===== PRINT 5 - PROCEDIMENTOS DE ENERGIA: RESUMO, NOVA LEITURA, RESUMO =====

BEGIN
    prc_resumo_energia(1, 2026, 11);
END;
/

DECLARE
    v_id_leitura  leitura_energia.id_leitura%TYPE;
BEGIN
    prc_registrar_leitura_energia(1, 900, 50, v_id_leitura,
                                  p_dt_leitura => TIMESTAMP '2026-11-10 08:00:00');

    BEGIN
        prc_registrar_leitura_energia(1, 900, 0, v_id_leitura);
    EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Erro esperado: ' || SQLERRM);
    END;

    BEGIN
        prc_registrar_leitura_energia(1, 900, 10, v_id_leitura,
                                      p_dt_leitura => TIMESTAMP '2099-01-01 00:00:00');
    EXCEPTION
        WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Erro esperado: ' || SQLERRM);
    END;
END;
/

BEGIN
    prc_resumo_energia(1, 2026, 11);
END;
/

PROMPT ===== PRINT 6 - PROCEDIMENTO DE CONSULTA: PRC_ALERTAS_VENCIMENTO =====

BEGIN
    prc_alertas_vencimento(1, DATE '2026-11-10');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 82, '-'));
    prc_alertas_vencimento(2, DATE '2026-11-10');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 82, '-'));
    prc_alertas_vencimento(8, DATE '2026-11-10', 30);
END;
/

PROMPT ===== PRINT 7 - LINHAS POR TABELA =====

SELECT 'USUARIO' AS tabela, COUNT(*) AS qtd_linhas FROM usuario
UNION ALL SELECT 'CATEGORIA',       COUNT(*) FROM categoria
UNION ALL SELECT 'TRANSACAO',       COUNT(*) FROM transacao
UNION ALL SELECT 'DIVIDA',          COUNT(*) FROM divida
UNION ALL SELECT 'DISPOSITIVO',     COUNT(*) FROM dispositivo
UNION ALL SELECT 'LEITURA_ENERGIA', COUNT(*) FROM leitura_energia;

PROMPT ===== PRINT 8 - O QUE OS PROCEDIMENTOS GRAVARAM =====

SELECT t.id_transacao, u.nome AS usuario, c.nome AS categoria, t.tipo, t.valor, t.origem
  FROM transacao t
  JOIN usuario   u ON u.id_usuario   = t.id_usuario
  JOIN categoria c ON c.id_categoria = t.id_categoria
 WHERE t.origem = 'WHATSAPP'
   AND t.descricao = 'Gastei 30 no mercado';

SELECT l.id_leitura, d.codigo, l.kwh, l.custo_estimado, l.dt_leitura
  FROM leitura_energia l
  JOIN dispositivo d ON d.id_dispositivo = l.id_dispositivo
 WHERE l.id_dispositivo = 1
 ORDER BY l.dt_leitura DESC;

ROLLBACK;
